"""
Meta's WhatsApp Cloud API webhook.

    GET  /webhooks/meta   Meta's one-time verification handshake
    POST /webhooks/meta   inbound messages. PUBLIC.

THIS IS THE ONE INBOUND WEBHOOK. The body is JSON, signed with HMAC-SHA256 over
the raw bytes, and a reply is NOT the HTTP response — it is a separate
authenticated call. (An earlier Twilio webhook was form-encoded, signed with
HMAC-SHA1 over sorted fields, and answered inline; it has been removed, and none
of its shape survives here.)

THE GET IS NOT OPTIONAL. Meta will not save a callback URL until it has GET it
with a challenge and been echoed the value back verbatim. Building only the POST
means the URL can never be registered at all, and the symptom is a 404 or a 405
in the Meta dashboard with no explanation.

THE SIGNATURE IS OVER THE RAW BODY. It must be computed on the exact bytes
received, before any JSON parsing: re-serialising the decoded payload changes
key order and whitespace, and the digest no longer matches. This is the single
most common way a correct-looking implementation rejects every real message.

IT ALWAYS ANSWERS 200 ONCE THE MESSAGE IS SAFE. Meta retries non-200s and will
disable a webhook that keeps failing. A message we have already seen, a status
callback, a shape we do not recognise — all are 200 and ignored.
"""

from __future__ import annotations

import hashlib
import hmac
import json
from typing import Any

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import JSONResponse, PlainTextResponse
from sqlalchemy import select
from sqlalchemy.orm import Session
from starlette.exceptions import HTTPException

from app.config import get_settings
from app.db import get_db
from app.models import WaMessage
from app.services.bot import handle, handle_order
from app.services.intake import MediaFetch
from app.services.outbound import send_reply
from app.services.whatsapp_cloud import (
    download_media,
    extract_messages,
    read_message,
)

router = APIRouter(tags=["webhooks"])

#: Where Meta posts. Registered in the Meta dashboard, so a silent change here
#: strands every inbound message.
META_WEBHOOK_PATH = "/webhooks/meta"


@router.get(META_WEBHOOK_PATH)
def verify(request: Request) -> Response:
    """
    Answer Meta's verification handshake.

    Meta GETs this URL once, when the callback is saved, with
    ``hub.mode=subscribe``, the verify token you typed into their form, and a
    random ``hub.challenge``. Echo the challenge back as PLAIN TEXT and the URL
    is accepted; anything else and it is rejected with no useful message.

    Returns:
        The challenge, verbatim, as ``text/plain``.

    Raises:
        HTTPException: 403 when the token does not match, 503 when no token is
            configured. Never echoes the challenge in either case — doing so
            would let anybody register our URL against their own app.

    Notes:
        THE CHALLENGE IS RETURNED AS TEXT, NOT JSON. Meta compares the response
        body byte for byte, so a quoted JSON string fails the comparison while
        looking correct in a browser.
    """
    settings = get_settings()
    expected = settings.whatsapp_verify_token
    if not expected:
        raise HTTPException(status_code=503, detail="WHATSAPP_VERIFY_TOKEN is not set")

    params = request.query_params
    mode = params.get("hub.mode")
    token = params.get("hub.verify_token")
    challenge = params.get("hub.challenge")

    # compare_digest, not ==: the token is a shared secret and a byte-by-byte
    # early return leaks it one character at a time.
    if mode != "subscribe" or not hmac.compare_digest(token or "", expected):
        raise HTTPException(status_code=403, detail="Verification failed")

    return PlainTextResponse(challenge or "")


def _signature_ok(raw: bytes, header: str | None, app_secret: str) -> bool:
    """
    Whether this body really came from Meta.

    Args:
        raw: The EXACT bytes received. Not the re-serialised payload — key
            order and whitespace would differ and every digest would fail.
        header: The ``X-Hub-Signature-256`` header, ``sha256=<hex>``.
        app_secret: The app secret, which is the shared key.

    Returns:
        True when the digest matches.
    """
    if not header or not header.startswith("sha256="):
        return False

    expected = hmac.new(app_secret.encode(), raw, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, header.removeprefix("sha256="))


def _fetch_for(media_id: str) -> MediaFetch:
    """Bind ONE media id into a fetch, so a loop cannot share the last one."""
    return lambda: download_media(media_id)


@router.post(META_WEBHOOK_PATH)
async def receive(request: Request, db: Session = Depends(get_db)) -> Response:
    """
    Receive inbound WhatsApp messages from Meta.

    Returns:
        200 with a tiny JSON body once every message is recorded — including
        for redeliveries and for payloads carrying no messages at all.

    Raises:
        HTTPException: 403 on a bad signature, 503 when unconfigured. Both are
            deliberate: this endpoint acts on what it is told.

    Notes:
        REPLIES ARE SENT, NOT RETURNED. Meta has no reply-in-the-response, so the
        bot's replies go out as separate authenticated calls after the message
        is committed. A send that fails must NOT fail the webhook — the message
        is already recorded, and a non-200 would have Meta redeliver it and run
        the whole conversation step twice.
    """
    settings = get_settings()
    app_secret = settings.whatsapp_app_secret
    if not app_secret:
        raise HTTPException(status_code=503, detail="WHATSAPP_APP_SECRET is not set")

    raw = await request.body()
    if not _signature_ok(raw, request.headers.get("X-Hub-Signature-256"), app_secret):
        raise HTTPException(status_code=403, detail="Bad signature")

    try:
        payload: dict[str, Any] = json.loads(raw)
    except json.JSONDecodeError:
        # Signed but unparseable. Acknowledge: a retry would arrive equally
        # unparseable and Meta disables webhooks that keep failing.
        return JSONResponse({"status": "ignored"})

    outgoing: list[tuple[str, list[Any]]] = []

    for message in extract_messages(payload):
        message_id, sender, text, media = read_message(message)
        if not message_id or not sender:
            continue

        already = db.scalar(select(WaMessage).where(WaMessage.provider_message_id == message_id))
        if already is not None:
            # A redelivery. Meta retries anything slow, and the whole point of
            # recording the id is that the second arrival changes nothing.
            continue

        db.add(
            WaMessage(
                provider_message_id=message_id,
                from_number=sender,
                body=text or None,
                media_count=len(media),
                raw=payload,
            )
        )

        if message.get("type") == "order":
            # A Multi-Product Message came back as a WhatsApp cart. It carries
            # the items but no name or address, so it opens the ordinary
            # checkout rather than a second, parallel order path.
            order = message.get("order") or {}
            outcome = handle_order(db, sender, order.get("product_items") or [])
        else:
            fetches: list[tuple[str, MediaFetch]] = [
                (media_id, _fetch_for(media_id)) for media_id, _ in media
            ]
            outcome = handle(db, sender, text, media=fetches)
        outgoing.append((sender, outcome.replies))

        # MESSAGES FOR OTHER PEOPLE, queued the same way and sent after the same
        # commit. A buyer placing an order is news the seller needs without
        # having to ask for it, and a seller confirming a payment is news the
        # buyer was promised in writing. Each goes to its own number.
        for other, reply in outcome.notify:
            outgoing.append((other, [reply]))

    # ONE COMMIT for every message record and everything the bot did. A reply
    # promising "added to your basket" must not survive a failed basket write.
    db.commit()

    # Sending happens AFTER the commit, deliberately. If a send fails we have
    # still recorded the message, so a redelivery is correctly recognised as one
    # rather than replaying the conversation. send_reply owns the Reply->wire
    # mapping and swallows a provider failure, so the worker and the webhook
    # cannot drift on how a link, an image-with-buttons or a list is sent.
    for sender, replies in outgoing:
        for reply in replies:
            send_reply(sender, reply)

    return JSONResponse({"status": "ok"})
