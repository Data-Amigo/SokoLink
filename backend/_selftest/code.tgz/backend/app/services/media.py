"""
Storing our own copies of images, because theirs expire.

    TikTok CDN url ──> download ──> media/covers/<platform>_<post_id>.jpg
                                          │
                                    served at /media/...

WHY THIS EXISTS, and it is not a nice-to-have: TikTok cover URLs are SIGNED and
carry an `x-expires` timestamp. Spike 02 flagged it; the demo storefront then
proved it by rendering ten broken images a week after the scrape. A stored copy
is the difference between a shop that works next month and a wall of broken
image icons.

Local disk today. In production the same paths move behind object storage and a
CDN — and because a Product stores a RELATIVE path, nothing else changes when
they do.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

from app.config import settings
from app.services.scraper import ScraperEngine, ScraperError

#: Where stored media lives. Gitignored in development — it is regenerable, and
#: large. CONFIGURABLE because a container's filesystem does not survive a
#: deploy: left at the default, every photo a seller forwarded disappears the
#: next time we push. Production points MEDIA_ROOT at a mounted volume, and
#: nothing else changes, because a Product stores a RELATIVE path.
MEDIA_ROOT = (
    Path(settings.media_root)
    if settings.media_root
    else Path(__file__).resolve().parents[2] / "media"
)
COVERS_DIR = MEDIA_ROOT / "covers"

#: Magic-number prefixes, longest first, mapped to the extension we store under.
#: WE SNIFF RATHER THAN TRUST A HEADER. The extension is what StaticFiles turns
#: into a Content-Type, and a PNG announced as JPEG renders fine in a browser —
#: which is exactly why it survives review — then fails in the link-preview
#: crawler that reads og:image and takes the header at its word.
_MAGIC: tuple[tuple[bytes, str], ...] = (
    (b"\x89PNG\r\n\x1a\n", "png"),
    (b"\xff\xd8\xff", "jpg"),
    (b"GIF8", "gif"),
)

#: The fallback when nothing matches. JPEG, because every catalogue photo a
#: phone camera produces is one, and a wrong extension costs a Content-Type
#: rather than the image.
_DEFAULT_EXT = "jpg"

#: The URL prefix these are served under. Products store a path relative to
#: MEDIA_ROOT, so moving to object storage changes this constant and nothing else.
MEDIA_URL_PREFIX = "/media"


def cover_filename(platform: str, post_id: str | None, source_url: str) -> str:
    """
    A stable filename for one post's cover.

    Args:
        platform: Which platform the post came from.
        post_id: The platform's post id, when there is one.
        source_url: Falls back to a hash of this for uploads and pasted links
            that carry no post id.

    Returns:
        A filename that is the same every time for the same post, so a re-sync
        overwrites rather than accumulating copies.
    """
    if post_id:
        stem = f"{platform}_{post_id}"
    else:
        digest = hashlib.sha256(source_url.encode("utf-8")).hexdigest()[:16]
        stem = f"{platform}_{digest}"
    return f"{stem}.jpg"


def image_extension(data: bytes) -> str:
    """
    Which extension to store these bytes under.

    Args:
        data: The start of the file is enough; the whole thing is fine too.

    Returns:
        An extension without the dot, e.g. ``"jpg"``.
    """
    for prefix, extension in _MAGIC:
        if data.startswith(prefix):
            return extension
    return _DEFAULT_EXT


def store_image_bytes(data: bytes, *, key: str) -> str | None:
    """
    Keep our own copy of image bytes we are already holding.

    Args:
        data: The image itself.
        key: Whatever identifies it upstream — a WhatsApp media id. Hashed, so
            a provider id containing a slash or a colon cannot escape the
            directory or produce a filename the OS rejects.

    Returns:
        A path relative to MEDIA_ROOT, e.g. ``covers/wa_1f3c….jpg``, or None if
        it could not be written.

    Notes:
        SEPARATE FROM ``store_cover`` BECAUSE THE BYTES ARE ALREADY IN HAND.
        A forwarded post is downloaded once to be shown to the model; asking a
        downloader to fetch it a second time would spend a Graph call to
        re-acquire something already in memory — and Meta's media URLs are
        signed and short-lived, so the second fetch is not even reliable.

        NEVER RAISES, matching ``store_cover``. A product without a photo is a
        worse card; a product that failed to exist is a lost sale. A full disk
        must not cost the seller their draft.
    """
    if not data:
        return None

    COVERS_DIR.mkdir(parents=True, exist_ok=True)

    digest = hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]
    filename = f"wa_{digest}.{image_extension(data)}"
    destination = COVERS_DIR / filename
    relative = f"covers/{filename}"

    # Already stored. The media id is the parse cache key too, so a redelivered
    # forward lands here with the same name and must not rewrite the file.
    if destination.exists() and destination.stat().st_size > 0:
        return relative

    try:
        destination.write_bytes(data)
    except OSError:
        return None

    return relative


def stored_image_path(key: str) -> str | None:
    """
    The copy we already keep for this key, if there is one.

    Args:
        key: The same upstream id given to :func:`store_image_bytes`.

    Returns:
        A path relative to MEDIA_ROOT, or None if nothing is stored.

    Notes:
        WHY THIS EXISTS. The parse cache means a redelivered forward is never
        downloaded again — so the bytes are gone, and without this lookup a
        second forward of a photo we already hold would produce a product with
        no picture. The extension is globbed because only the bytes knew it.
    """
    digest = hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]
    try:
        for candidate in sorted(COVERS_DIR.glob(f"wa_{digest}.*")):
            if candidate.is_file() and candidate.stat().st_size > 0:
                return f"covers/{candidate.name}"
    except OSError:
        return None
    return None


def store_cover(
    scraper: ScraperEngine,
    *,
    remote_url: str,
    platform: str,
    post_id: str | None,
) -> str | None:
    """
    Download a cover and keep our own copy.

    Args:
        scraper: Used for the download, so the content-type guard and the Apify
            token handling live in one place rather than being reimplemented.
        remote_url: The platform's (expiring) URL.
        platform: For the filename.
        post_id: For the filename.

    Returns:
        A path relative to MEDIA_ROOT, e.g. ``covers/tiktok_7671596.jpg``, or
        None if the download failed.

    Notes:
        Returns None rather than raising, for ANY failure. A missing cover
        degrades one card; letting it escape would abort the sync and lose the
        products too — which is a far worse outcome than a placeholder image.

        The catch is deliberately broad. An earlier version caught only
        ScraperError, which meant a timeout, a full disk or an engine that
        simply had not implemented the method took the whole product down with
        it. A function whose entire contract is "never let an image failure
        cost us a product" cannot afford to enumerate the failures in advance.

        The caller records the failure in its warnings; nothing is swallowed
        silently.
    """
    COVERS_DIR.mkdir(parents=True, exist_ok=True)

    filename = cover_filename(platform, post_id, remote_url)
    destination = COVERS_DIR / filename

    # Already have it. Covers do not change once posted, so re-downloading on
    # every sync would spend bandwidth to overwrite a file with itself.
    if destination.exists() and destination.stat().st_size > 0:
        return f"covers/{filename}"

    try:
        data = scraper.download_media(remote_url, expect="image")
        destination.write_bytes(data)
    except (ScraperError, OSError, NotImplementedError):
        return None

    return f"covers/{filename}"


def public_url(stored_path: str | None) -> str | None:
    """
    Turn a stored relative path into a URL the browser can request.

    Args:
        stored_path: What ``store_cover`` returned, or a full URL for records
            predating local storage.

    Returns:
        A URL, or None.
    """
    if not stored_path:
        return None
    # Anything already absolute is a legacy remote URL — pass it through rather
    # than mangling it into a broken local path.
    if stored_path.startswith(("http://", "https://")):
        return stored_path
    return f"{MEDIA_URL_PREFIX}/{stored_path.lstrip('/')}"


def absolute_url(stored_path: str | None) -> str | None:
    """
    The same URL, but fully qualified with the site's public origin.

    WHY THIS EXISTS SEPARATELY FROM ``public_url``. A page renders images with a
    root-relative path, which is correct and smaller. **A link preview cannot.**
    When a seller pastes their shop link into WhatsApp, Meta's crawler fetches
    the page from outside and reads ``og:image`` with no origin to resolve
    against — a relative path there yields a preview with no picture at all.

    That is the first thing a buyer sees of a shop, on the surface this whole
    product now depends on, so it gets its own function rather than a filter
    each template must remember to reach for.

    Args:
        stored_path: What ``store_cover`` returned, or a full URL.

    Returns:
        An absolute URL, or None.
    """
    relative = public_url(stored_path)
    if relative is None or relative.startswith(("http://", "https://")):
        return relative

    # Imported here, not at module scope: config is lazy on purpose, and a
    # top-level read would resolve settings at import time.
    from app.config import get_settings

    return f"{get_settings().app_base_url}{relative}"
